<?php
/**
* Plugin Name: Slise Href Lang
* Plugin URI: https://www.selise.ch/
* Description: Custom Href Lang Tag from JSON File.
* Version: 1.0
* Author: Maruf Al Bashir
* Author URI: http://marufcse.com/
**/

defined( 'ABSPATH' ) || exit;


require_once('href-lang.php');



// data formater excel to json
// https://beautifytools.com/excel-to-json-converter.php