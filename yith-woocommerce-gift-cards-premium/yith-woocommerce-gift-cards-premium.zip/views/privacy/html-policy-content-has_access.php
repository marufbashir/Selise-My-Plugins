<p><?php _ex( 'Members of our team have access to the information you provide us. For example, both Administrators and Shop Managers can access:', 'Privacy Policy Content', 'yith-woocommerce-gift-cards' ) ?></p>

<ul>
    <li><?php _ex( 'Sender name, recipient name, recipient email address, delivery date, message, amount and balance of the gift card you have purchased', 'Privacy Policy Content', 'yith-woocommerce-gift-cards' ); ?></li>
</ul>